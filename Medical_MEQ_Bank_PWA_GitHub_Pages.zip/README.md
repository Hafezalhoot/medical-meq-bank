# Medical MEQ & Short Question Review Bank

Offline-first Progressive Web App (PWA) for lecture-based MEQ cases, high-yield short questions, image spots, rapid recall and saved self-assessment.

## Features

- Permanent web link through GitHub Pages
- Installable on iPad, iPhone, Android, Windows and macOS
- Works offline after the first successful online load
- Local progress with JSON backup and restore
- Automatic update prompt when a new lecture version is published
- Standalone offline HTML copy in `offline/`

## GitHub Pages deployment

1. Create a public repository and place these files in its root.
2. Open **Settings → Pages**.
3. Under **Build and deployment**, select **GitHub Actions**.
4. Push to the `main` branch. The included workflow publishes the site.

## Updating the bank

Replace `index.html`, increment the cache version in `service-worker.js`, and update `version.json`. Push the changes to `main`; the same public link updates automatically.

## Offline use

Open the published site once while online, then install it or add it to the home screen. A direct standalone copy is also available at `offline/Medical_MEQ_Review_Bank_Offline.html`.
